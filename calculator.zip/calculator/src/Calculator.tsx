import { useState } from 'react'

export const Calculator = () => {
	const [signo, setSigno] = useState<string>("");
	const [operacion, setOperacion] = useState<string>("");
	const generarSigno = (): string => {
		const signos = ["+", "-", "*", "/"];
		const indiceAleatorio = Math.floor(Math.random() * signos.length);
		return signos[indiceAleatorio];
	}
	const generarOperacion = () => {
		const numeros = [1,2,3,4,5,6,7,8,9,0];
		let numero = Math.floor(Math.random()*numeros.length);
		setSigno(generarSigno());
		setOperacion(numeros[numero]+signo+numeros[numero]);
	}
	return (
		<>
			<button type='button' onClick={(e) => {
				generarOperacion();
			}
			}
			>Generar signo</button>
			<p>{operacion}</p>
		</>
	)
}